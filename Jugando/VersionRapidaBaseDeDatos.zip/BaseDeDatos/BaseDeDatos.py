import shelve
shelfFile = shelve.open('MyData')
def BaseDeDatos():
    while (True):

        print('Seleccione alguna de las siguientes opciones')
        print('\n')
        print('Presione el número correspondiente')
        print('\n')
        print('1 - Agregar Registro Nuevo')
        print('2 - Consultar Registro')
        print('3 - Modificar Registro')
        print('4 - Borrar Registro')
        print('5 - Ver Cantidad de Registros en la base')
        print('6 - Ver todos los registros de la base de datos')
        print('\n')

        respuestaValida = False
        while (not respuestaValida):            
            respuesta = int(input('Selección de opción: '))
            if (respuesta<=6 and respuesta >=1):
                respuestaValida = True
            else:
                print('Ingrese un número en el rango indicado')
        if (respuesta==1):
            respuestaAgregarRegistro = Preguntas(1)
            if (respuestaAgregarRegistro):
                print('\n')
                print('#Inicio Agregar Registro#')
                agregoRegistro()
                print('\n')
                print('#Registro Agregado#')
                print('\n')
                
        elif (respuesta==2):
             respuestaConsultarRegistro = Preguntas(2)
             if(respuestaConsultarRegistro):
                 print('\n')
                 print('                 #Consulta Iniciada#                 ')
                 consultoRegistro()
                 print('\n')
                 print('                 #Consulta Terminada#                 ')
                 print('\n')
                
        elif (respuesta==3):
            respuestaModificarRegistro = Preguntas(3)
            if(respuestaModificarRegistro):
                modificoRegistro()

        elif (respuesta==4):
            respuestaBorrarRegistro = Preguntas(6)
            if(respuestaBorrarRegistro):
                print('\n')
                print('                 #Preparación de borrado de registro...#                 ')
                borrarRegistro()
                print('\n')
                print('                 #Registro Borrado#                 ')
                print('\n')

        elif (respuesta==5):
            print('\n')
            print(f'Hay actualmente {len(list(shelfFile.keys()))} registros en la base de datos')
            print('\n')

        else:
            print('\n')
            print('                 #Mostrando todos los registros de la base de datos#                 ')
            mostrarTodos()
            print('\n')
            print('                 #Finalizado#                 ')


        respuestaReiniciar = Preguntas(8)
        if (not respuestaReiniciar):
            print('                 #Cerrando Programa.....#                 ')
            break
        



def mostrarTodos():
    if len(list(shelfFile.keys()))>0:
        for i in range(0,len(list(shelfFile.keys()))):
            print(f'Registro {i+1}: ')
            print(f'''CodigoBaseDeDatos: {shelfFile[str(i)][0]}, Fecha: {shelfFile[str(i)][1]}, Codigo: {shelfFile[str(i)][2]}, Nombre: {shelfFile[str(i)][3]},
Prod: {shelfFile[str(i)][4]}, Canal: {shelfFile[str(i)][5]}, Valor: {shelfFile[str(i)][6]}, Cantidad: {shelfFile[str(i)][7]}, Observaciones: {shelfFile[str(i)][8]}''')
            print('\n')
    else:
        print('---> No hay registros en la base de datos <---')

def existeCodigo():
    print('\n')
    existeCodigo = False
    while (not existeCodigo):
        respuesta=str(int(input('Ingrese un codigoUnico para modificar el registro: ')))
        if (respuesta in list(shelfFile.keys())):
            existeCodigo = True 
            print('\n')
        else:
            print('\n')
            print('---> códigoUnico ingresado NO VALIDO <---')
            print('---> Ingrese un códigoUnico válido <---')            
            respuestaQuedarse=Preguntas(9)
            if(not respuestaQuedarse):
                respuesta = -1
                existeCodigo = True
            print('\n')
            
    return respuesta

            
def borrarRegistro():
    codigoBorrar = existeCodigo()

    if (codigoBorrar>=0):        
        print('\n')
        print(f'''CodigoBaseDeDatos: {shelfFile[codigoModificar][0]}, Fecha: {shelfFile[codigoModificar][1]}, Codigo: {shelfFile[codigoModificar][2]},
Nombre: {shelfFile[codigoModificar][3]}, Prod: {shelfFile[codigoModificar][4]}, Canal: {shelfFile[codigoModificar][5]},
Valor: {shelfFile[codigoModificar][6]}, Cantidad: {shelfFile[codigoModificar][7]}, Observaciones: {shelfFile[codigoModificar][8]}''')
        print('\n')
        respuesta = Preguntas(7)

        if (respuesta):
            del shelfFile[codigoBorrar]
        

    
    

def modificoRegistro():
    
    codigoModificar=existeCodigo()
    
            
    print('El registro encontrado es el siguiente: ')
    print('\n')
    print(f'''CodigoBaseDeDatos: {shelfFile[codigoModificar][0]}, Fecha: {shelfFile[codigoModificar][1]}, Codigo: {shelfFile[codigoModificar][2]},
Nombre: {shelfFile[codigoModificar][3]}, Prod: {shelfFile[codigoModificar][4]}, Canal: {shelfFile[codigoModificar][5]},
Valor: {shelfFile[codigoModificar][6]}, Cantidad: {shelfFile[codigoModificar][7]}, Observaciones: {shelfFile[codigoModificar][8]}''')

    print('\n')
    respuestaPregunta = Preguntas(5)
    if (respuestaPregunta):
        PreguntaModificar(respuesta)
        print('\n')
        print('                 #Registro Modificado#                 ')
        print('\n')
    else:
        print('\n')
        print('                 #No Modificado#                 ')
        print('\n')
        
    

    
    
        
def consultoRegistro():
    nombreAbuscar =  str(input('Ingrese un nombre para buscar en la base de datos: '))
    codigosUnicos = []
    print('\n')    

    for i in list(shelfFile.keys()):
        if shelfFile[i][3] == nombreAbuscar:
            codigosUnicos.append(i)
    if len(codigosUnicos) ==0:
        print('---> No se han encontrado registros con ese nombre <---')
        
    else:
        for i in range(0,len(codigosUnicos)):
            print(f'Registro {i+1}: ')
            print(f'''CodigoBaseDeDatos: {shelfFile[codigosUnicos[i]][0]}, Fecha: {shelfFile[codigosUnicos[i]][1]}, Codigo: {shelfFile[codigosUnicos[i]][2]},
Nombre: {shelfFile[codigosUnicos[i]][3]}, Prod: {shelfFile[codigosUnicos[i]][4]}, Canal: {shelfFile[codigosUnicos[i]][5]},
Valor: {shelfFile[codigosUnicos[i]][6]}, Cantidad: {shelfFile[codigosUnicos[i]][7]}, Observaciones: {shelfFile[codigosUnicos[i]][8]}''')
            print('\n')
            



        

def agregoRegistro():
    datosCorrectos = False
    while(not datosCorrectos):
        if len(list(shelfFile.keys())) == 0:
            codigoUnico = '0'
        else:
            codigoUnico = str(int(list(shelfFile.keys())[-1]) + 1)

        fechaCorrecta = False
        while (not fechaCorrecta):
            fecha = str(input('Ingrese una fecha en formato DD-MM-YYYY '))
            if (fechaValida(fecha)):
                fechaCorrecta = True
            else:
                print('Ingrese una fecha correcta en el formato pedido')

        
        codigo =  esNumeroValido('Ingrese un codigo: ')   
        nombre = str(input('Ingrese un nombre: '))
        prod = str(input('Ingrese un prod: '))
        canal = str(input('Ingrese un canal: '))  
        valor = esNumeroValido('valor: ')
        cantidad = esNumeroValido('cantidad: ')
        observaciones = str(input('Observaciones: '))
        datosChequeados = chequeoDatos([fecha, codigo, nombre, prod, canal, valor, cantidad, observaciones])
        if (datosChequeados):
            datosCorrectos = True

    shelfFile[codigoUnico] = [codigoUnico, fecha, codigo, nombre, prod, canal, valor, cantidad, observaciones]


def esNumeroValido(string):
    esNumero = False
    while (not esNumero):
        try:
            numero = int(input(string))
            esNumero = True
        except:
            print('Ingrese un valor númerico')
    return numero
    
def fechaValida(fecha):
    return (len(fecha)==10 and esNumero([fecha[0],fecha[1],fecha[3],fecha[4],fecha[6],fecha[7],fecha[8],fecha[9]]) and fecha[2]=='-' and fecha[5] == '-')

def esNumero(lista):
    cumple = True
    for i in lista:
        if (i=='1' or i=='2' or i =='0' or i=='3' or i=='4' or i=='5' or i=='6' or i=='7' or i=='8' or i=='9'):
            continue
        else:
            cumple = False
    return cumple

def chequeoDatos(lista):
    for i in range(0,3):
        print('\n')
    print('Chequeo de valores ingresados: ')
    print('\n')
    for i in range(0,len(lista)):
        print(lista[i])
    print('\n')
    respuesta = Preguntas(4)
    return respuesta



def PreguntaModificar(codigo):
        print('\n')
        print('¿Qué campo desea modificar?')
        print('Presione el número correspondiente al campo a ser modificado')
        print('\n')
        print('1 - Fecha')
        print('2 - Codigo')
        print('3 - Nombre')
        print('4 - Prod')
        print('5 - Canal')
        print('6 - Valor')
        print('7 - Cantidad')
        print('8 - Observaciones')
        print('\n')

        respuestaValida = False
        while (not respuestaValida):            
            respuesta = int(input('Campo a ser modificado: '))
            if (respuesta<=8 and respuesta >=1):
                respuestaValida = True
            else:
                print('Ingrese un número en el rango indicado')

        codigoUnicoNuevo = codigo
        fechaNueva = shelfFile[codigo][1]
        codigoNuevo = shelfFile[codigo][2]
        nombreNuevo = shelfFile[codigo][3]
        prodNuevo = shelfFile[codigo][4]
        canalNuevo = shelfFile[codigo][5]
        valorNuevo = shelfFile[codigo][6]
        cantidadNueva = shelfFile[codigo][7]
        observacionesNueva = shelfFile[codigo][8]

        if respuesta==1:
            fechaNueva = str(input('Ingrese una fecha: '))
        elif respuesta==2:
            codigoNuevo = int(input('Ingrese un codigo: '))
        elif respuesta==3:
            nombreNuevo = str(input('Ingrese un nombre: '))        
        elif respuesta==4:
            prodNuevo = str(input('Ingrese un prod: '))         
        elif respuesta==5:
            canalNuevo = str(input('Ingrese un canal: '))             
        elif respuesta==6:
            valorNuevo = int(input('valor: '))        
        elif respuesta==7:
            cantidadNueva = int(input('cantidad: '))        
        else:
            observacionesNueva = str(input('Observaciones: '))

        del shelfFile[codigo]
        shelfFile[codigoUnicoNuevo] = [codigoUnicoNuevo, fechaNueva, codigoNuevo, nombreNuevo, prodNuevo, canalNuevo, valorNuevo, cantidadNueva, observacionesNueva]

        

def Preguntas(numeroPregunta):
    while(True):
        if(numeroPregunta==1):
            respuesta=str(input('¿Desea agregar un registro nuevo? Y/N '))
        elif (numeroPregunta==2):
            respuesta=str(input('¿Desea consultar un registro existente? Y/N '))
        elif (numeroPregunta==3):
            respuesta=str(input('¿Desea modificar un registro existente? Y/N '))
        elif (numeroPregunta==4):
            respuesta=str(input('¿Son los datos correctos? Y/N '))
        elif (numeroPregunta==5):
            respuesta=str(input('¿Es correcto el registro a ser modificado? Y/N '))
        elif (numeroPregunta==6):
            respuesta=str(input('¿Desea borrar un registro? Y/N '))
        elif (numeroPregunta==7):
            respuesta=str(input('¿Está seguro que desea borrar el registro anterior? Y/N '))
        elif (numeroPregunta==8):
            respuesta=str(input('¿Desea volver al menú inicial? Y/N '))
        else:
            respuesta=str(input('Presione "Y" para ingresar otro codigoUnico o presione "N" para volver al menú inicial Y/N '))

       
            
        if (respuesta.lower() == 'y'):
            return True            
        elif (respuesta.lower() == 'n'):
            return False
        else:
            print('Presione la tecla adecuada: Y o N')
        
    
        

BaseDeDatos()
